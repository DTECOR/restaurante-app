const { expect } = require('chai');
const { addIngredient } = require('../../backend/controllers/inventoryController');

describe('Inventory Controller', () => {
  it('should add an ingredient successfully', async () => {
    const req = { body: { name: 'Tomate', quantity: 10, unit_of_measure: 'kg' } };
    const res = {
      status: (code) => ({ json: (data) => data }),
    };

    const result = await addIngredient(req, res);
    expect(result).to.have.property('name', 'Tomate');
  });
});