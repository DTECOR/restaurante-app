const request = require('supertest');
const app = require('../../backend/app');

describe('Menu Routes', () => {
  it('should get the weekly menu', async () => {
    const response = await request(app).get('/api/menu/weekly');
    expect(response.status).to.equal(200);
    expect(response.body).to.be.an('array');
  });
});