const { chromium } = require('playwright');

describe('Frontend Tests', () => {
  let browser, page;

  beforeAll(async () => {
    browser = await chromium.launch();
    page = await browser.newPage();
  });

  afterAll(async () => {
    await browser.close();
  });

  it('should load the home page', async () => {
    await page.goto('http://localhost:3000');
    const title = await page.title();
    expect(title).toBe('Restaurante App');
  });
});