CREATE TABLE orders (
  id_order SERIAL PRIMARY KEY,
  id_table INT,
  status VARCHAR(50) DEFAULT 'pending',
  order_type VARCHAR(20) CHECK (order_type IN ('local', 'online')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);