CREATE TABLE recipes (
  id_recipe SERIAL PRIMARY KEY,
  id_dish INT REFERENCES dishes(id_dish),
  id_ingredient INT REFERENCES ingredients(id_ingredient),
  required_quantity DECIMAL(10, 2) NOT NULL
);