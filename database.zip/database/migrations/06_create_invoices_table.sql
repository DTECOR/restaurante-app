CREATE TABLE invoices (
  id_invoice SERIAL PRIMARY KEY,
  id_order INT REFERENCES orders(id_order),
  total_amount DECIMAL(10, 2) NOT NULL,
  payment_method VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);