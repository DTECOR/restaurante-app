CREATE TABLE promotions (
  id_promotion SERIAL PRIMARY KEY,
  id_dish INT REFERENCES dishes(id_dish),
  discount DECIMAL(5, 2),
  start_date DATE,
  end_date DATE
);