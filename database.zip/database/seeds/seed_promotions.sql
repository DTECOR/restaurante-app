INSERT INTO promotions (id_dish, discount, start_date, end_date)
VALUES
  (1, 10.00, '2023-10-01', '2023-10-15'),
  (2, 15.00, '2023-10-16', '2023-10-30');