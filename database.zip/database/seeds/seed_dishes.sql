INSERT INTO dishes (name, price, description, photo_url, is_active)
VALUES
  ('Arroz con Pollo', 15000, 'Delicioso arroz con pollo', 'https://example.com/arroz-con-pollo.jpg', TRUE),
  ('Papas Fritas', 8000, 'Papas fritas crujientes', 'https://example.com/papas-fritas.jpg', TRUE),
  ('Ensalada César', 12000, 'Ensalada fresca con aderezo césar', 'https://example.com/ensalada-cesar.jpg', TRUE);