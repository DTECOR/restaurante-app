INSERT INTO users (username, password, role)
VALUES
  ('superadmin', 'superadmin123', 'SuperAdmin'),
  ('admin', 'admin123', 'Admin'),
  ('cook', 'cook123', 'Cocinero'),
  ('waiter', 'waiter123', 'Mesero'),
  ('cashier', 'cashier123', 'Cajero');