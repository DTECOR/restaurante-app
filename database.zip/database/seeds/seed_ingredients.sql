INSERT INTO ingredients (name, quantity, unit_of_measure)
VALUES
  ('Arroz', 50.00, 'kg'),
  ('Pollo', 30.00, 'kg'),
  ('Papas', 20.00, 'kg'),
  ('Aceite', 10.00, 'L'),
  ('Sal', 5.00, 'kg');