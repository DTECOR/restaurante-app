const pool = require('../utils/dbConnection')();

// Obtener todos los ingredientes
exports.getAllIngredients = async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM ingredients');
    res.status(200).json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener ingredientes' });
  }
};

// Agregar un nuevo ingrediente
exports.addIngredient = async (req, res) => {
  const { name, quantity, unit_of_measure } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO ingredients (name, quantity, unit_of_measure) VALUES ($1, $2, $3) RETURNING *',
      [name, quantity, unit_of_measure]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Error al agregar ingrediente' });
  }
};

// Actualizar cantidad de un ingrediente
exports.updateIngredientQuantity = async (req, res) => {
  const { id_ingredient, quantity } = req.body;
  try {
    const result = await pool.query(
      'UPDATE ingredients SET quantity = $1 WHERE id_ingredient = $2 RETURNING *',
      [quantity, id_ingredient]
    );
    res.status(200).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Error al actualizar ingrediente' });
  }
};