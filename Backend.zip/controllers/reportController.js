const pool = require('../utils/dbConnection')();

// Generar reporte de ventas por rango de fechas
exports.generateSalesReport = async (req, res) => {
  const { start_date, end_date } = req.query;
  try {
    const result = await pool.query(
      'SELECT * FROM invoices WHERE date BETWEEN $1 AND $2',
      [start_date, end_date]
    );
    res.status(200).json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Error al generar el reporte' });
  }
};