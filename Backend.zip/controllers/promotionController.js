const pool = require('../utils/dbConnection')();

// Obtener promociones activas
exports.getActivePromotions = async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM promotions WHERE CURRENT_DATE BETWEEN start_date AND end_date'
    );
    res.status(200).json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener promociones' });
  }
};

// Crear una nueva promoción
exports.createPromotion = async (req, res) => {
  const { id_dish, discount, start_date, end_date } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO promotions (id_dish, discount, start_date, end_date) VALUES ($1, $2, $3, $4) RETURNING *',
      [id_dish, discount, start_date, end_date]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Error al crear la promoción' });
  }
};