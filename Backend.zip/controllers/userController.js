const pool = require('../utils/dbConnection')();

// Obtener todos los usuarios
exports.getAllUsers = async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM users');
    res.status(200).json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener usuarios' });
  }
};

// Actualizar rol de un usuario
exports.updateUserRole = async (req, res) => {
  const { id_user, role } = req.body;
  try {
    const result = await pool.query(
      'UPDATE users SET role = $1 WHERE id_user = $2 RETURNING *',
      [role, id_user]
    );
    res.status(200).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Error al actualizar el rol del usuario' });
  }
};