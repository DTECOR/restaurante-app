const pool = require('../utils/dbConnection')();

// Crear una nueva orden
exports.createOrder = async (req, res) => {
  const { id_table, type, details } = req.body;
  try {
    const orderResult = await pool.query(
      'INSERT INTO orders (id_table, status, order_type) VALUES ($1, $2, $3) RETURNING *',
      [id_table, 'pending', type]
    );

    const orderId = orderResult.rows[0].id_order;
    for (const detail of details) {
      await pool.query(
        'INSERT INTO order_details (id_order, id_dish, quantity) VALUES ($1, $2, $3)',
        [orderId, detail.id_dish, detail.quantity]
      );
    }

    res.status(201).json(orderResult.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Error al crear la orden' });
  }
};

// Cambiar estado de una orden
exports.updateOrderStatus = async (req, res) => {
  const { id_order, status } = req.body;
  try {
    const result = await pool.query(
      'UPDATE orders SET status = $1 WHERE id_order = $2 RETURNING *',
      [status, id_order]
    );
    res.status(200).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Error al actualizar el estado de la orden' });
  }
};