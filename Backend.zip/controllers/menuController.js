const pool = require('../utils/dbConnection')();

// Obtener el menú semanal
exports.getWeeklyMenu = async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM dishes WHERE is_active = true');
    res.status(200).json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener el menú' });
  }
};

// Crear un nuevo plato
exports.createDish = async (req, res) => {
  const { name, price, description, ingredients } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO dishes (name, price, description) VALUES ($1, $2, $3) RETURNING *',
      [name, price, description]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Error al crear el plato' });
  }
};