const pool = require('../utils/dbConnection')();

class User {
  static async findAll() {
    const result = await pool.query('SELECT * FROM users');
    return result.rows;
  }

  static async findById(id) {
    const result = await pool.query('SELECT * FROM users WHERE id_user = $1', [id]);
    return result.rows[0];
  }

  static async create(userData) {
    const { username, password, role } = userData;
    const result = await pool.query(
      'INSERT INTO users (username, password, role) VALUES ($1, $2, $3) RETURNING *',
      [username, password, role]
    );
    return result.rows[0];
  }
}

module.exports = User;