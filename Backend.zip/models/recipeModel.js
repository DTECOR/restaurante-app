const pool = require('../utils/dbConnection')();

class Recipe {
  static async findAll() {
    const result = await pool.query('SELECT * FROM recipes');
    return result.rows;
  }

  static async findById(id) {
    const result = await pool.query('SELECT * FROM recipes WHERE id_recipe = $1', [id]);
    return result.rows[0];
  }

  static async create(recipeData) {
    const { id_dish, id_ingredient, required_quantity } = recipeData;
    const result = await pool.query(
      'INSERT INTO recipes (id_dish, id_ingredient, required_quantity) VALUES ($1, $2, $3) RETURNING *',
      [id_dish, id_ingredient, required_quantity]
    );
    return result.rows[0];
  }
}

module.exports = Recipe;