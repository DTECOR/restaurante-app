const pool = require('../utils/dbConnection')();

class Order {
  static async findAll() {
    const result = await pool.query('SELECT * FROM orders');
    return result.rows;
  }

  static async findById(id) {
    const result = await pool.query('SELECT * FROM orders WHERE id_order = $1', [id]);
    return result.rows[0];
  }

  static async create(orderData) {
    const { id_table, status, order_type } = orderData;
    const result = await pool.query(
      'INSERT INTO orders (id_table, status, order_type) VALUES ($1, $2, $3) RETURNING *',
      [id_table, status, order_type]
    );
    return result.rows[0];
  }

  static async updateStatus(id, status) {
    const result = await pool.query(
      'UPDATE orders SET status = $1 WHERE id_order = $2 RETURNING *',
      [status, id]
    );
    return result.rows[0];
  }
}

module.exports = Order;