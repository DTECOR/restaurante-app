const pool = require('../utils/dbConnection')();

class Dish {
  static async findAll() {
    const result = await pool.query('SELECT * FROM dishes');
    return result.rows;
  }

  static async findById(id) {
    const result = await pool.query('SELECT * FROM dishes WHERE id_dish = $1', [id]);
    return result.rows[0];
  }

  static async create(dishData) {
    const { name, price, description } = dishData;
    const result = await pool.query(
      'INSERT INTO dishes (name, price, description) VALUES ($1, $2, $3) RETURNING *',
      [name, price, description]
    );
    return result.rows[0];
  }
}

module.exports = Dish;