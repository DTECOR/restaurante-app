const pool = require('../utils/dbConnection')();

class Ingredient {
  static async findAll() {
    const result = await pool.query('SELECT * FROM ingredients');
    return result.rows;
  }

  static async findById(id) {
    const result = await pool.query('SELECT * FROM ingredients WHERE id_ingredient = $1', [id]);
    return result.rows[0];
  }

  static async create(ingredientData) {
    const { name, quantity, unit_of_measure } = ingredientData;
    const result = await pool.query(
      'INSERT INTO ingredients (name, quantity, unit_of_measure) VALUES ($1, $2, $3) RETURNING *',
      [name, quantity, unit_of_measure]
    );
    return result.rows[0];
  }
}

module.exports = Ingredient;