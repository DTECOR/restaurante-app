const pool = require('../utils/dbConnection')();

class Promotion {
  static async findAll() {
    const result = await pool.query('SELECT * FROM promotions');
    return result.rows;
  }

  static async findById(id) {
    const result = await pool.query('SELECT * FROM promotions WHERE id_promotion = $1', [id]);
    return result.rows[0];
  }

  static async create(promotionData) {
    const { id_dish, discount, start_date, end_date } = promotionData;
    const result = await pool.query(
      'INSERT INTO promotions (id_dish, discount, start_date, end_date) VALUES ($1, $2, $3, $4) RETURNING *',
      [id_dish, discount, start_date, end_date]
    );
    return result.rows[0];
  }
}

module.exports = Promotion;