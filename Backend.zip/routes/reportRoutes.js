const express = require('express');
const { generateSalesReport } = require('../controllers/reportController');

const router = express.Router();

router.get('/sales', generateSalesReport);

module.exports = router;