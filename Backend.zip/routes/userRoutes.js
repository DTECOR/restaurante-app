const express = require('express');
const { getAllUsers, updateUserRole } = require('../controllers/userController');

const router = express.Router();

router.get('/users', getAllUsers);
router.put('/users/update-role', updateUserRole);

module.exports = router;