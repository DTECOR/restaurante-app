const express = require('express');
const { getActivePromotions, createPromotion } = require('../controllers/promotionController');

const router = express.Router();

router.get('/active', getActivePromotions);
router.post('/create', createPromotion);

module.exports = router;