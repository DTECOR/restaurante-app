const express = require('express');
const { createOrder, updateOrderStatus } = require('../controllers/orderController');

const router = express.Router();

router.post('/create', createOrder);
router.put('/update-status', updateOrderStatus);

module.exports = router;