const express = require('express');
const { getWeeklyMenu, createDish } = require('../controllers/menuController');

const router = express.Router();

router.get('/weekly', getWeeklyMenu);
router.post('/create', createDish);

module.exports = router;