const express = require('express');
const {
  getAllIngredients,
  addIngredient,
  updateIngredientQuantity,
} = require('../controllers/inventoryController');

const router = express.Router();

router.get('/ingredients', getAllIngredients);
router.post('/ingredients/add', addIngredient);
router.put('/ingredients/update', updateIngredientQuantity);

module.exports = router;