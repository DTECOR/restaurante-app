const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const dbConnection = require('./utils/dbConnection');
const authRoutes = require('./routes/authRoutes');
const inventoryRoutes = require('./routes/inventoryRoutes');
const menuRoutes = require('./routes/menuRoutes');
const orderRoutes = require('./routes/orderRoutes');
const userRoutes = require('./routes/userRoutes');
const promotionRoutes = require('./routes/promotionRoutes');
const reportRoutes = require('./routes/reportRoutes');
const authMiddleware = require('./middlewares/authMiddleware');
const roleMiddleware = require('./middlewares/roleMiddleware');

// Cargar variables de entorno
dotenv.config({ path: './config/.env' });

// Conectar a la base de datos
dbConnection();

// Crear la aplicación Express
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Rutas
app.use('/api/auth', authRoutes);
app.use('/api/inventory', authMiddleware, roleMiddleware(['Admin']), inventoryRoutes);
app.use('/api/menu', authMiddleware, roleMiddleware(['Admin', 'Cocinero']), menuRoutes);
app.use('/api/orders', authMiddleware, roleMiddleware(['Mesero', 'Cajero']), orderRoutes);
app.use('/api/users', authMiddleware, roleMiddleware(['SuperAdmin']), userRoutes);
app.use('/api/promotions', authMiddleware, roleMiddleware(['Admin']), promotionRoutes);
app.use('/api/reports', authMiddleware, roleMiddleware(['SuperAdmin']), reportRoutes);

// Ruta de página principal (opcional)
app.get('/', (req, res) => {
  res.send('Bienvenido a la API del Restaurante');
});

// Middleware de manejo de errores
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({ error: 'Algo salió mal' });
});

module.exports = app;