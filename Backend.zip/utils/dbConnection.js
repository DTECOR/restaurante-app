const { Pool } = require('pg');
const dotenv = require('dotenv');

dotenv.config({ path: './config/.env' });

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

pool.on('error', (err) => {
  console.error('Error al conectar a la base de datos:', err);
});

module.exports = () => pool;