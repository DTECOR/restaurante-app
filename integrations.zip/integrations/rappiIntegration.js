const axios = require('axios');

const syncRappiOrders = async (order) => {
  try {
    const response = await axios.post('https://api.rappi.com/orders', order);
    console.log('Pedido sincronizado con Rappi:', response.data);
  } catch (error) {
    console.error('Error al sincronizar pedido con Rappi:', error);
  }
};

module.exports = syncRappiOrders;