const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

const processPayment = async (paymentData) => {
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: paymentData.amount,
      currency: 'usd',
      payment_method: paymentData.payment_method,
      confirmation_method: 'manual',
      confirm: true,
    });
    return paymentIntent;
  } catch (error) {
    console.error('Error al procesar el pago:', error);
    throw error;
  }
};

module.exports = processPayment;