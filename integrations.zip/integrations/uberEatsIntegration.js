const axios = require('axios');

const syncUberEatsOrders = async (order) => {
  try {
    const response = await axios.post('https://api.ubereats.com/orders', order);
    console.log('Pedido sincronizado con Uber Eats:', response.data);
  } catch (error) {
    console.error('Error al sincronizar pedido con Uber Eats:', error);
  }
};

module.exports = syncUberEatsOrders;