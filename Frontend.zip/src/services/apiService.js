import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

const apiService = {
  get: async (endpoint) => {
    const response = await axios.get(`${API_URL}${endpoint}`);
    return response.data;
  },
  post: async (endpoint, data) => {
    const response = await axios.post(`${API_URL}${endpoint}`, data);
    return response.data;
  },
};

export default apiService;