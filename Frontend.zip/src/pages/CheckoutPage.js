import React, { useState } from 'react';
import apiService from '../services/apiService';

function CheckoutPage() {
  const [paymentMethod, setPaymentMethod] = useState('cash');

  const handlePayment = async () => {
    try {
      await apiService.post('/api/payments/process', { method: paymentMethod });
      alert('Pago realizado con éxito');
    } catch (error) {
      console.error('Error al procesar el pago:', error);
    }
  };

  return (
    <div>
      <h2>Pago</h2>
      <select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
        <option value="cash">Efectivo</option>
        <option value="card">Tarjeta</option>
      </select>
      <button onClick={handlePayment}>Pagar</button>
    </div>
  );
}

export default CheckoutPage;