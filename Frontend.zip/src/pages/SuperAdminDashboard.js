import React, { useEffect, useState } from 'react';
import apiService from '../services/apiService';

function SuperAdminDashboard() {
  const [promotions, setPromotions] = useState([]);

  useEffect(() => {
    const fetchPromotions = async () => {
      const data = await apiService.get('/api/promotions/active');
      setPromotions(data);
    };
    fetchPromotions();
  }, []);

  return (
    <div>
      <h1>Panel de SuperAdmin</h1>
      <h2>Promociones Activas</h2>
      <ul>
        {promotions.map((promo) => (
          <li key={promo.id_promotion}>
            {promo.dish_name}: {promo.discount}% de descuento
          </li>
        ))}
      </ul>
    </div>
  );
}

export default SuperAdminDashboard;