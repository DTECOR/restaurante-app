import React, { useEffect, useState } from 'react';
import apiService from '../services/apiService';

function AdminDashboard() {
  const [inventory, setInventory] = useState([]);

  useEffect(() => {
    const fetchInventory = async () => {
      const data = await apiService.get('/api/inventory/ingredients');
      setInventory(data);
    };
    fetchInventory();
  }, []);

  return (
    <div>
      <h1>Panel de Administrador</h1>
      <h2>Inventario</h2>
      <ul>
        {inventory.map((item) => (
          <li key={item.id_ingredient}>
            {item.name}: {item.quantity} {item.unit_of_measure}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default AdminDashboard;