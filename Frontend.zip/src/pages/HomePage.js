import React from 'react';
import PromotionBanner from '../components/PromotionBanner';

function HomePage() {
  return (
    <div>
      <h1>Bienvenido a Nuestro Restaurante</h1>
      <PromotionBanner />
    </div>
  );
}

export default HomePage;