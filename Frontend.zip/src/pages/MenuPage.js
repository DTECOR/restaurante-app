import React, { useEffect, useState } from 'react';
import apiService from '../services/apiService';

function MenuPage() {
  const [menu, setMenu] = useState([]);

  useEffect(() => {
    const fetchMenu = async () => {
      const data = await apiService.get('/api/menu/weekly');
      setMenu(data);
    };
    fetchMenu();
  }, []);

  return (
    <div>
      <h1>Menú Semanal</h1>
      {menu.map((dish) => (
        <div key={dish.id_dish}>
          <h2>{dish.name}</h2>
          <p>{dish.description}</p>
          <p>Precio: ${dish.price}</p>
        </div>
      ))}
    </div>
  );
}

export default MenuPage;