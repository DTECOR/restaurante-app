import React from 'react';

function Footer() {
  return (
    <footer>
      <p>&copy; 2023 Restaurante App. Todos los derechos reservados.</p>
    </footer>
  );
}

export default Footer;