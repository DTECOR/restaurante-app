import React from 'react';

function MenuCard({ dish }) {
  return (
    <div className="menu-card">
      <img src={dish.photo_url} alt={dish.name} />
      <h3>{dish.name}</h3>
      <p>{dish.description}</p>
      <p>Precio: ${dish.price}</p>
      <button>Agregar al carrito</button>
    </div>
  );
}

export default MenuCard;