import React, { useState } from 'react';
import apiService from '../services/apiService';

function OrderForm({ onSubmit }) {
  const [orderDetails, setOrderDetails] = useState([]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await apiService.post('/api/orders/create', { details: orderDetails });
      onSubmit();
    } catch (error) {
      console.error('Error al enviar la orden:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Registrar Orden</h2>
      {/* Aquí se pueden agregar campos dinámicos para seleccionar platos */}
      <button type="submit">Enviar Orden</button>
    </form>
  );
}

export default OrderForm;