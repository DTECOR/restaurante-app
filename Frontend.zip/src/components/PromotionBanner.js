import React, { useEffect, useState } from 'react';
import apiService from '../services/apiService';

function PromotionBanner() {
  const [promotions, setPromotions] = useState([]);

  useEffect(() => {
    const fetchPromotions = async () => {
      const data = await apiService.get('/api/promotions/active');
      setPromotions(data);
    };
    fetchPromotions();
  }, []);

  return (
    <div>
      <h2>Promociones Activas</h2>
      {promotions.map((promo) => (
        <div key={promo.id_promotion}>
          <p>{promo.discount}% de descuento en {promo.dish_name}</p>
        </div>
      ))}
    </div>
  );
}

export default PromotionBanner;